# JRGame

<a href="https://jrgame.herokuapp.com/">Demo</a>

## Built With
- Node.js (Express.js)
- Socket.io
- Phaser 3
- Parcel

## Author
[Jacky Rusly](https://www.jackyrusly.web.id)

## License
This project is licensed under the [MIT License](https://opensource.org/licenses/MIT)
