export const FADE_DURATION = 1000;
export const WIDTH = 350;
export const HEIGHT = 350;