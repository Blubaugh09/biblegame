class BaseModel {
    constructor(id, x, y) {
        this.id = id;
        this.x = x;
        this.y = y;
    }
}

export default BaseModel;