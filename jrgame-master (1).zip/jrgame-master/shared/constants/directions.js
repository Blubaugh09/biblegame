export const UP = 'up';
export const LEFT = 'left';
export const DOWN = 'down';
export const RIGHT = 'right';
