export const TOWN = 'Town';
export const HOUSE_1 = 'House_1';
export const HOUSE_2 = 'House_2';
